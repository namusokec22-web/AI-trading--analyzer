# AI Trading Analyzer — Android App

This is an APK-ready Android Studio project for the trading-analysis app.

## What is included

- Custom AI Trading Analyzer launcher icon/logo
- Android phone UI
- Chart screenshot picker
- Extracted chart-text input
- OHLC/CSV input
- Local technical-analysis engine:
  - EMA 20/50/200
  - RSI 14
  - ATR 14
  - trend detection
  - support/resistance
  - entry / stop / target
  - R:R
  - position-size estimate
  - explicit NO TRADE state
- Dark mobile trading interface
- No broker/live order execution
- GitHub Actions workflow for building an APK without installing Android Studio locally

## Important

The current build contains a local baseline analysis engine. It is not a guaranteed-profitable AI trader.

For full AI screenshot interpretation, the next production step is to connect the app to a secure HTTPS backend. Do NOT put an OpenAI/API secret directly in the Android APK.

## Build with Android Studio

1. Install Android Studio on a Windows/Mac/Linux computer.
2. Open this entire `AI_Trading_Analyzer_Android` folder.
3. Let Gradle sync.
4. Select an emulator or connect your Android phone with USB debugging.
5. Choose **Build > Build APK(s)**.
6. The debug APK will be created at:
   `app/build/outputs/apk/debug/app-debug.apk`

## Build from GitHub

The included `.github/workflows/build-apk.yml` can build the debug APK in GitHub Actions.

After the workflow finishes:
1. Open the workflow run.
2. Open the Artifacts section.
3. Download `AI-Trading-Analyzer-debug-apk`.
4. Extract the APK.
5. Transfer it to the phone and install it.

Android may ask you to allow installation from the browser/file manager used to open the APK.

## Next upgrade

The intended production architecture is:

Android app
  -> secure HTTPS backend
  -> AI vision/chart extraction
  -> technical-analysis engine
  -> risk engine
  -> trade plan / NO TRADE

Backtesting and paper trading should be completed before any live broker connection.
